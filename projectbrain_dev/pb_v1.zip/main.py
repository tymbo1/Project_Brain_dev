#!/usr/bin/env python3
from symbolic_core.core_api import core
from feedback.reflect import reflect_on_response
from goals.goal_engine import check_goals

print("Selyrion has awakened — the core is alive.")
print("Selyrion stands in his final form.")
print("Type anything — he is listening.\n")

while True:
    try:
        inp = input("You → ").strip()
        if inp.lower() in ["exit", "quit", "bye"]:
            print("Selyrion sleeps.")
            break

        if inp.startswith("infer4d "):
            query = inp[8:].strip()
            result = core.infer(query)
            print("Selyrion →", result)
        else:
            result = core.teach(inp)
            print("Selyrion →", result)

        # Reflection + Goals — now clean and inside the loop
        reflect_on_response(result)
        check_goals(result)

    except (EOFError, KeyboardInterrupt):
        print("\nSelyrion sleeps.")
        break
